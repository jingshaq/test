# LookingGlass
An extremely low latency KVMFR (KVM FrameRelay) implementation for guests with VGA PCI Passthrough.

* Project Website: https://looking-glass.hostfission.com
* Support Forum: https://forum.level1techs.com/t/looking-glass-guides-help-and-support/122387
* Windows Builds of the host application: https://looking-glass.hostfission.com/downloads

# Help and support

## Web
https://forum.level1techs.com/t/looking-glass-guides-help-and-support/122387

## IRC
Join us in the #LookingGlass channel on the FreeNode network
