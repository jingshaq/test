### Required information

Host CPU:
Host GPU:
Guest GPU:
Host Kernel version:
Host QEMU version:

Please describe what were you doing when the problem occured. If the Windows host application crashed please check for file named `looking-glass-host.dmp` and attach it to this bug report.

**Reports that do no include this information will be ignored and closed**
