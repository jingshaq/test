The full source code for the AWSASxx.DLLs and libray, that can be directly
compiled into 32-bit and 64-bit machine code is available for a modest fee of
$99.00.

The full source code can, of course, be used to build stand alone executables.

The supplied code includes also the Midl file(s) used, even though not
necessary, because we have done the Midl compilation and inserted into the
project the needed header and C files.

The source code was developed in Visual Studio 2010, using the platform toolset
v90. It will be straightforward to adjust it to build under Visual Studio 2008
or 2005. The C++/C files and header files need no change.

It will build without change either in Unicode, Multibyte or "Not set" character
sets. The supplied Dlls have been built in the Unicode character set.

The source code is rich in comments, written in common C++ and will be easily
understood by most developers.

It is also feasible to rewrite the code for other computer languages that have
easy access to the Windows API. One of such languages is Delphi.

But you are not allowed to sell the derived, modified or rewritten source code.
You are only allowed to reproduce and redistribute executable files (full
EXE applications) created using the code. See the License_Lib_Source_Code.txt
file for details.








