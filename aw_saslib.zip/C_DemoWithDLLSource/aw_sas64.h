
#pragma once
#include "stdafx.h"


UINT WINAPI sendCtrlAltDel(BOOL asUser, INT iSession=-1);

