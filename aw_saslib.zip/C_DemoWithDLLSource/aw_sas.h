
#pragma once
#include <WinDef.h>

#ifdef __cplusplus
extern "C"{
#endif 

UINT sendCtrlAltDel(BOOL asUser, INT iSession=-1);

#ifdef __cplusplus
}
#endif
