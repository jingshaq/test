
#include "stdafx.h"
#include <commctrl.h>
#include <WinGDI.h>
#include <wchar.h>
#include <stdio.h>
#include "c_awsasdemo.h"
#ifdef _WIN64
#include "aw_sas64.h"
#else
#include "aw_sas32.h"
#endif



enum {
	DIALOG_OK,
	DIALOG_CANCEL,
};

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	INT_PTR Status;

	MyRegisterClass(hInstance);

	Status = DialogBox( hInstance, _T("AWSASDemo"), NULL, 
						(DLGPROC)WndProc );
	if (Status != DIALOG_CANCEL )
		return 1;

	return 0;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= DLGWINDOWEXTRA;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_AWSPS));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_BTNFACE+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= _T("AWSASDemo");
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_AWSPS));

	return RegisterClassEx(&wcex);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	BOOL bAsUser;
	TCHAR cSession[8];
	INITCOMMONCONTROLSEX structCC;
	UINT iSession;
	TCHAR info[] = _T("This is a %d-bit executable signed with authenticode. Place it in a protected folder like Programs Files or launch it in the Local System Account then push the Send Ctrl-Alt-Del button.  See Readme.txt file for full details.");
	TCHAR resultOK[] = _T("Success");
	TCHAR resultError[] = _T("Error %u (Refer to error codes table)");
	TCHAR *buffer;
	static HWND hWndSession;
	static HWND hWndUpDown;
	static HWND hwndResult;
	int intOS;
	HWND hWndInfo;
	UINT retValue;

	switch (message)
	{
	case WM_INITDIALOG:
		structCC.dwSize = sizeof INITCOMMONCONTROLSEX;
		structCC.dwICC = ICC_WIN95_CLASSES | ICC_STANDARD_CLASSES | ICC_UPDOWN_CLASS;
		InitCommonControlsEx(&structCC);
		CheckRadioButton(hWnd, IDC_RBASUSER, IDC_RBASLOCSYS, IDC_RBASLOCSYS);
		hwndResult = GetDlgItem(hWnd, IDC_EDOUTPUT);
		hWndSession = GetDlgItem(hWnd, IDC_EDSESSION);
		hWndUpDown = GetDlgItem(hWnd, IDC_SPEDITSESSION);
		hWndInfo = GetDlgItem(hWnd, IDC_INFO);
		SetWindowText(hWndSession, _T("-1"));
		SendDlgItemMessage (hWnd, IDC_SPEDITSESSION, UDM_SETRANGE, 0, 0xFFFF7FFF);
#ifdef _WIN64
		SetWindowText(hWnd, _T("64-bit AW-SAS Demo"));
#else
		SetWindowText(hWnd, _T("32-bit AW-SAS Demo"));
#endif
		buffer = new TCHAR[0x100];
		memset(buffer,0,0x100*sizeof TCHAR);
#ifdef _WIN64
		intOS = 64;
#else
		intOS = 32;
#endif
		_stprintf_s(buffer, 0x100-2, info, intOS);
		SetWindowText(hWndInfo, buffer);
		delete [] buffer;

		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDCANCEL:
			EndDialog( hWnd, DIALOG_CANCEL );
			break;
		case IDC_RBASUSER:
			CheckRadioButton(hWnd, IDC_RBASUSER, IDC_RBASLOCSYS, IDC_RBASUSER);
			EnableWindow(hWndUpDown, FALSE);
			EnableWindow(hWndSession, FALSE);
			break;
		case IDC_RBASLOCSYS:
			CheckRadioButton(hWnd, IDC_RBASUSER, IDC_RBASLOCSYS, IDC_RBASLOCSYS);
			EnableWindow(hWndUpDown, TRUE);
			EnableWindow(hWndSession, TRUE);
			break;
		case IDC_CTRLALTDEL:
			bAsUser = IsDlgButtonChecked(hWnd, IDC_RBASUSER);
			GetWindowText(hWndSession,cSession,7); 
			iSession = _ttoi(cSession);
			retValue = sendCtrlAltDel(bAsUser, iSession);
			if (retValue == NO_ERROR)
				SetWindowText(hwndResult, resultOK);
			else
			{
				buffer = new TCHAR[0x50];
				memset(buffer,0,0x50*sizeof TCHAR);
				_stprintf_s(buffer, 0x50-2, resultError, retValue);
				SetWindowText(hwndResult, buffer);
				delete[] buffer;
			}
			break;
		default:
			return FALSE;
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_CTLCOLORSTATIC:
		{
			HDC hdcStatic = (HDC) wParam;
			if (GetDlgItem(hWnd, IDC_INFO ) == (HWND) lParam)
			{
				SetTextColor(hdcStatic, RGB(0xFF,0x7F,0x50)); 
				SetBkColor(hdcStatic, RGB(0,0,0));
				return (INT_PTR) CreateSolidBrush(RGB(0,0,0));
			}
			else if(GetDlgItem(hWnd, IDC_EDOUTPUT ) == (HWND) lParam)
			{
				SetTextColor(hdcStatic, RGB(0,0xFF,0xFF)); // Cyan
				SetBkColor(hdcStatic, RGB(0,0,0));
				return (INT_PTR) CreateSolidBrush(RGB(0,0,0));
			}
			break;
		}
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_CLOSE:
		EndDialog( hWnd, DIALOG_CANCEL);
		break;
	default:
		return FALSE;
	}
	return FALSE;
}


