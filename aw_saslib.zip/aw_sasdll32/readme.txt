You can use the DLL contained in this folder to build 32-bit applications able
to produce Ctrl-Alt-Del.
The DLL has a dependency on msvcr90.dll. Even though, it is almost ubiquitous,
developers must take that into account and consider distributing msvcr90.dll.
If they have the AW_SAS library source code, they can compile it to link
statically and will have no dependency on msvcr90.dll (increases the size by
around 50KB)


