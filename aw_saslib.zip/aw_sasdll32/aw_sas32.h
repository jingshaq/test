
#pragma once
#include <WinDef.h>

UINT WINAPI sendCtrlAltDel(BOOL asUser, INT iSession=-1);
