This 32-bit demo application file is statically linked and have no external
dependencies on redistributables,
