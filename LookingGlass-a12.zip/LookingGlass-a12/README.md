# LookingGlass
An extremely low latency KVMFR (KVM FrameRelay) implementation for guests with VGA PCI Passthrough.

* Project Website: https://looking-glass.hostfission.com
* Support Forum: https://forum.level1techs.com/t/looking-glass-guides-help-and-support/122387

## Obtaining and using Looking Glass

Please see https://looking-glass.hostfission.com/quickstart

## Latest Version

If you would like to use the latest bleeding edge version of Looking Glass please be aware there will be no support at this time.
Latest bleeding edge builds of the Windows host application can be obtained from: https://ci.appveyor.com/project/gnif/lookingglass/build/artifacts

# Help and support

## Web
https://forum.level1techs.com/t/looking-glass-guides-help-and-support/122387

## IRC
Join us in the #LookingGlass channel on the FreeNode network
